create database PatientDB 
go
use PatientDB
go
create table Patient
(
	Patient_Id int identity (100000,1) primary key,
	Patient_LastName nvarchar (50) not null,
	Patient_FirstName nvarchar (50) not null,
	Patient_Address nvarchar (50) not null,

)
go
insert into Patient values('Espinosa', 'Christian', 'Koronadal')
insert into Patient values('Lamalan', 'Charmeia', 'Manila')
insert into Patient values('David', 'Suzi', 'North America')


go
select *from Patient