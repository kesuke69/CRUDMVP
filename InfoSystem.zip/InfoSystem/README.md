CRUD MVP Implementation
