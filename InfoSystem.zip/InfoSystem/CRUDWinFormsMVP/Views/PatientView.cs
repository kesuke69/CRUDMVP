﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CRUDWinFormsMVP.Views
{
    public partial class PatientView : Form, IPatientView
    {
        //Fields
        private string message;
        private bool isSuccessful;
        private bool isEdit ;

        //Constructor
        public PatientView()
        {
            InitializeComponent();
            AssociateAndRaiseViewEvents();
            tabControl1.TabPages.Remove(tabPagePatientDetail);
            btnClose.Click += delegate { this.Close(); };
        }

        private void AssociateAndRaiseViewEvents()
        {
            //Search
            btnSearch.Click += delegate { SearchEvent?.Invoke(this, EventArgs.Empty); };
            txtSearch.KeyDown += (s, e) =>
              {
                  if (e.KeyCode == Keys.Enter)
                      SearchEvent?.Invoke(this, EventArgs.Empty);
              };
            //Add Patient
            btnAddNew.Click += delegate 
            {
                AddNewEvent?.Invoke(this, EventArgs.Empty);
                tabControl1.TabPages.Remove(tabPagePatientList);
                tabControl1.TabPages.Add(tabPagePatientDetail);
                tabPagePatientDetail.Text = "Add New Patient";

            };

            //Edit Patient
            btnEdit.Click += delegate 
            {
                EditEvent?.Invoke(this, EventArgs.Empty);
                
                tabControl1.TabPages.Remove(tabPagePatientList);
                tabControl1.TabPages.Add(tabPagePatientDetail);
                tabPagePatientDetail.Text = "Edit Patient";
            };

            //Save Patient
            btnSave.Click += delegate 
            {
                SaveEvent?.Invoke(this, EventArgs.Empty);
                if (isSuccessful)
                {
                    tabControl1.TabPages.Remove(tabPagePatientDetail);
                    tabControl1.TabPages.Add(tabPagePatientList);
                }
                MessageBox.Show(Message);
            };
            
            //Cancel
            btnCancel.Click += delegate 
            {
                CancelEvent?.Invoke(this, EventArgs.Empty);
                tabControl1.TabPages.Remove(tabPagePatientDetail);
                tabControl1.TabPages.Add(tabPagePatientList);
            };

            //Delete Patient
            btnDelete.Click += delegate 
            {
               
                var result=MessageBox.Show("Are you sure you want to delete the Patient Record?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result==DialogResult.Yes)
                {
                    DeleteEvent?.Invoke(this, EventArgs.Empty);
                    MessageBox.Show(Message);
                }

            };
        }

     

        //Properties
        public string PatientId
        {
            get { return txtPatientId.Text; }
            set { txtPatientId.Text = value; }
        }

        public string PatientLname
        {
            get { return txtPatientLname.Text; }
            set { txtPatientLname.Text = value; }
        }

        public string PatientFname
        {
            get { return txtPatientFname.Text; }
            set { txtPatientFname.Text = value; }
        }

        public string PatientAddress
        {
            get { return txtPatientAddress.Text; }
            set { txtPatientAddress.Text = value; }
        }

        public string SearchValue
        {
            get { return txtSearch.Text; }
            set { txtSearch.Text = value; }
        }

        public bool IsEdit
        {
            get { return isEdit; }
            set { isEdit = value; }
        }

        public bool IsSuccessful
        {
            get { return isSuccessful; }
            set { isSuccessful = value; }
        }

        public string Message
        {
            get { return message; }
            set { message = value; }
        }

        //Events
        public event EventHandler SearchEvent;
        public event EventHandler AddNewEvent;
        public event EventHandler EditEvent;
        public event EventHandler DeleteEvent;
        public event EventHandler SaveEvent;
        public event EventHandler CancelEvent;

        //Methods
        public void SetPatientListBindingSource(BindingSource patientList)
        {
            dataGridView.DataSource = patientList;
        }

        //Singleton pattern (Open Single Form Instance)
        private static PatientView instance;
        

        public static PatientView GetInstance(Form parentContainer) {
            if (instance == null || instance.IsDisposed)
            {
                instance = new PatientView();
                instance.MdiParent = parentContainer;
                instance.FormBorderStyle = FormBorderStyle.None;
                instance.Dock = DockStyle.Fill;
            }
            else
            {
                if (instance.WindowState == FormWindowState.Minimized)
                    instance.WindowState = FormWindowState.Normal;
                instance.BringToFront();
            }
            return instance;
        }

       
    }
}
