﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUDWinFormsMVP.Views
{
    public partial class MainView : Form, IMainView
    {
        public MainView()
        {
            InitializeComponent();
            btnPatient.Click += delegate { ShowPatientView?.Invoke(this, EventArgs.Empty); };
        }

        public event EventHandler ShowAppointmentView;
        public event EventHandler ShowMedicationView;
        public event EventHandler ShowPatientView;
    }
}
