﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUDWinFormsMVP.Models
{
    public interface IPatientRepository
    {
        void Add(PatientModel patientModel);
        void Edit(PatientModel patientModel);
        void Delete(int id);
        IEnumerable<PatientModel> GetAll();
        IEnumerable<PatientModel> GetByValue(string value);//Search
    }
}
