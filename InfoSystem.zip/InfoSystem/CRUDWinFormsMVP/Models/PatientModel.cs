﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace CRUDWinFormsMVP.Models
{
    public class PatientModel
    {
        //Fields
        private int id;
        private string lname;
        private string fname;
        private string address;

        //Properties - Validations
        [DisplayName("Patient ID")]
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        [DisplayName("Patient Last Name")]
        [Required(ErrorMessage ="Patient Last name is required")]
        [StringLength(50,MinimumLength =3, ErrorMessage ="Patient last name must be between 3 and 50 characters")]
        public string Lname
        {
            get { return lname; }
            set { lname = value; }
        }

        [DisplayName("Patient First Name")]
        [Required(ErrorMessage = "Patient First name is required")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Patient first name must be between 3 and 50 characters")]
        public string Fname
        {
            get { return fname; }
            set { fname = value; }
        }

        [DisplayName("Patient Address")]
        [Required(ErrorMessage = "Patient Address is required")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Patient address must be between 3 and 50 characters")]
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
    }
}
