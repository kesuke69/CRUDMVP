﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using CRUDWinFormsMVP.Models;

namespace CRUDWinFormsMVP._Repositories
{
    public class PatientRepository : BaseRepository, Models.IPatientRepository
    {
        private int _;

        //Constructor
        public PatientRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }
        //Methods
        public IEnumerable<PatientModel> GetAll()
        {
            var patientList = new List<PatientModel>();
            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand())
            {
                connection.Open();
                command.Connection = connection;
                command.CommandText = "Select *from Patient order by Patient_Id desc";
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var patientModel = new PatientModel();
                        patientModel.Id = (int)reader[0];
                        patientModel.Lname = reader[1].ToString();
                        patientModel.Fname = reader[2].ToString();
                        patientModel.Address = reader[3].ToString();
                        patientList.Add(patientModel);
                    }
                }
                connection.Close();
            }
            return patientList;
        }

        public IEnumerable<PatientModel> GetByValue(string value)
        {
            var patientList = new List<PatientModel>();
            int patientId = int.TryParse(value, out _) ? Convert.ToInt32(value) : 0;
            string patientLname = value;
            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand())
            {
                connection.Open();
                command.Connection = connection;
                command.CommandText = @"Select *from Patient
                                        where Patient_Id=@id or Patient_LastName like @name+'%' 
                                        order by Patient_Id desc";
                command.Parameters.Add("@id", SqlDbType.Int).Value = patientId;
                command.Parameters.Add("@name", SqlDbType.NVarChar).Value = patientLname;

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var patientModel = new PatientModel();
                        patientModel.Id = (int)reader[0];
                        patientModel.Lname = reader[1].ToString();
                        patientModel.Fname = reader[2].ToString();
                        patientModel.Address = reader[3].ToString();
                        patientList.Add(patientModel);
                    }
                }
                connection.Close();
            }
            return patientList;
        }
        public void Add(PatientModel patientModel)
        {
            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand())
            {
                connection.Open();
                command.Connection = connection;
                command.CommandText = "insert into Patient values (@lname, @fname, @address)";
                command.Parameters.Add("@lname", SqlDbType.NVarChar).Value = patientModel.Lname;
                command.Parameters.Add("@fname", SqlDbType.NVarChar).Value = patientModel.Fname;
                command.Parameters.Add("@address", SqlDbType.NVarChar).Value = patientModel.Address;
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
        public void Delete(int id)
        {
            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand())
            {
                connection.Open();
                command.Connection = connection;
                command.CommandText = "delete from Patient where Patient_Id=@id";
                command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                command.ExecuteNonQuery();
                connection.Close();
            }
        }

        public void Edit(PatientModel patientModel)
        {
            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand())
            {
                connection.Open();
                command.Connection = connection;
                command.CommandText = @"update Patient 
                                    set Patient_LastName=@lname,Patient_FirstName= @fname,Patient_Address= @address 
                                    where Patient_Id=@id";
                command.Parameters.Add("@lname", SqlDbType.NVarChar).Value = patientModel.Lname;
                command.Parameters.Add("@fname", SqlDbType.NVarChar).Value = patientModel.Fname;
                command.Parameters.Add("@address", SqlDbType.NVarChar).Value = patientModel.Address;
                command.Parameters.Add("@id", SqlDbType.Int).Value = patientModel.Id;
                command.ExecuteNonQuery();
                connection.Close();
            }


        }
    }
}
