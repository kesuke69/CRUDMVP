﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CRUDWinFormsMVP.Models;
using CRUDWinFormsMVP.Views;
using CRUDWinFormsMVP._Repositories;
using System.Windows.Forms;

namespace CRUDWinFormsMVP.Presenters
{
    public class MainPresenter
    {
        private IMainView mainView;
        private readonly string sqlConnectionString;

        public MainPresenter(IMainView mainView, string sqlConnectionString)
        {
            this.mainView = mainView;
            this.sqlConnectionString = sqlConnectionString;
            this.mainView.ShowPatientView += ShowPatientView;
        }
        private void ShowPatientView(object sender, EventArgs e)
        {
            IPatientView view = PatientView.GetInstance((MainView)mainView);
            IPatientRepository repository = new PatientRepository(sqlConnectionString);
            new PatientPresenter(view, repository);
        }
    }

}
