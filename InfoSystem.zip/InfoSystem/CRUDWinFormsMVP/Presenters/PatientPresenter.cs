﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CRUDWinFormsMVP.Models;
using CRUDWinFormsMVP.Views;

namespace CRUDWinFormsMVP.Presenters
{
    public class PatientPresenter
    {
        //Fields
        private IPatientView view;
        private IPatientRepository repository;
        private BindingSource patientsBindingSource;
        private IEnumerable<PatientModel> patientList;

        //Constructor
        public PatientPresenter(IPatientView view, IPatientRepository repository)
        {
            this.patientsBindingSource = new BindingSource();
            this.view = view;
            this.repository = repository;
            //Subscribe event handler methods to view events
            this.view.SearchEvent += SearchPatient;
            this.view.AddNewEvent += AddNewPatient;
            this.view.EditEvent += LoadSelectedPatientToEdit;
            this.view.DeleteEvent += DeleteSelectedPatient;
            this.view.SaveEvent += SavePatient;
            this.view.CancelEvent += CancelAction;
            //Set patient bindind source
            this.view.SetPatientListBindingSource(patientsBindingSource);
            //Load patient list view
            LoadAllPatientList();
            //Show view
            this.view.Show();
        }

        //Methods
        private void LoadAllPatientList()
        {
            patientList = repository.GetAll();
            patientsBindingSource.DataSource = patientList;//Set data source.
        }
        private void SearchPatient(object sender, EventArgs e)
        {
            bool emptyValue = string.IsNullOrWhiteSpace(this.view.SearchValue);
            if (emptyValue == false)
                patientList = repository.GetByValue(this.view.SearchValue);
            else patientList = repository.GetAll();
            patientsBindingSource.DataSource = patientList;
        }

        private void AddNewPatient(object sender, EventArgs e)
        {
            view.IsEdit = false;

        }

        private void LoadSelectedPatientToEdit(object sender, EventArgs e)
        {
            var patient = (PatientModel)patientsBindingSource.Current;

            view.PatientId = patient.Id.ToString();
            view.PatientLname = patient.Lname;
            view.PatientFname = patient.Fname;
            view.PatientAddress = patient.Address;
            view.IsEdit=true;
        }

        private void SavePatient(object sender, EventArgs e)
        {
            var model = new PatientModel();
            model.Id = Convert.ToInt32(view.PatientId);
            model.Lname = view.PatientLname;
            model.Fname = view.PatientFname;
            model.Address = view.PatientAddress;
            try
            {
                new Common.ModelDataValidation().Validate(model);
                if (view.IsEdit)//Edit model
                {
                    repository.Edit(model);
                    view.Message = "Patient edited successfuly";
                }
                else //Add new model
                {
                    repository.Add(model);
                    view.Message = "Patient added sucessfully";
                }
                view.IsSuccessful = true;
                LoadAllPatientList();
                CleanviewFields();
            }
            catch (Exception ex)
            {
                view.IsSuccessful = false;
                view.Message = ex.Message;
            }
        }

        private void CleanviewFields()
        {
            view.PatientId = "0";
            view.PatientLname = "";
            view.PatientFname = "";
            view.PatientAddress = "";
        }

        private void CancelAction(object sender, EventArgs e)
        {
            CleanviewFields();
        }

        private void DeleteSelectedPatient(object sender, EventArgs e)
        {
            try
            {
                var patient = (PatientModel)patientsBindingSource.Current;
                repository.Delete(patient.Id);
                view.IsSuccessful = true;
                view.Message = "Patient deleted successfully";
                LoadAllPatientList();
            }
            catch (Exception ex)
            {
                view.IsSuccessful = false;
                view.Message = "An error ocurred, could not delete patient";
            }
        }
        
       
      
    }
}
